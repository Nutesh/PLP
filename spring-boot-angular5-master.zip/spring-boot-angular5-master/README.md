# spring-boot-angular5
This is a sample project using Angular 5 and spring Boot.Spring boot has been used to expose REST Endpoints and the client is written in angular. 
This is a complete web application with a connectivity to mysql database. We have used spring data to connect to the database and perform CRUD
operation.

The application has CRUD operation example for user entity. Here, you can create
a user, read users record and also delete user. The complete explanation can be 
found on my blog - [spring boot angular 5 example](http://www.devglan.com/spring-boot/spring-boot-angular-spring-data-example)

This project uses following versions:

1. Spring Boot v1.5.9
2. Angular v5.0.0
3. Maven

Angular 8 just got released this May and here is the article for [Angular 8 CRUD example](https://www.devglan.com/angular/angular-8-crud-example).
